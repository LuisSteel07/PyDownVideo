# Version 0.7.10
- Mejora del diseño.
- Agrego de botón para cancelar la selección de video a descargar
- Mejora de la documentación del proyecto.
- Optimización de la conversión de videos.

# Version 0.7.6
- Cambios en el rendimiento y lógica del código del programa.

# Version 0.7.2
- Agrego de más opciones de descarga.
- Agrego de opción de agregar subtitulos a la descarga.


### [URL Prueba:](https://www.youtube.com/watch?v=_27eD49ePQE)